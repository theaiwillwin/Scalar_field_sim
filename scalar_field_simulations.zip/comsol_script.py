"""
from mph import ModelUtil, Session

session = Session()
mu = session.mu
model = mu.create(tag="ScalarField")
...
"""